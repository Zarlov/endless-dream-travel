<?php
namespace Espo\Modules\EndlessDreamTravel\Classes\RecordHooks\Booking;

use Espo\Core\Record\Hook\SaveHook;
use Espo\ORM\Entity;
use Espo\ORM\EntityManager;

class RecalculateTripTotals implements SaveHook
{
    public function __construct(private EntityManager $entityManager)
    {}

    public function process(Entity $entity): void
    {
        $tripIdList = array_values(array_unique(array_filter([
            $entity->get('tripId'),
            $entity->getFetched('tripId'),
        ])));

        foreach ($tripIdList as $tripId) {
            $this->recalculate((string) $tripId);
        }
    }

    private function recalculate(string $tripId): void
    {
        $trip = $this->entityManager->getEntityById('EdtTrip', $tripId);
        if (!$trip) {
            return;
        }

        $gross = 0.0;
        $balance = 0.0;
        $expectedCommission = 0.0;
        $count = 0;
        $bookingList = $this->entityManager
            ->getRDBRepository('EdtBooking')
            ->where(['tripId' => $tripId])
            ->find();

        foreach ($bookingList as $booking) {
            if (!$booking->get('reportableSale')) {
                continue;
            }

            if (in_array($booking->get('status'), ['Canceled', 'Removed from Live Source'], true)) {
                continue;
            }

            $count++;
            $gross += (float) ($booking->get('grossSale') ?? 0);
            $balance += (float) ($booking->get('balanceDue') ?? 0);
            $expectedCommission += (float) ($booking->get('expectedCommission') ?? 0);
        }

        $trip->set([
            'componentCount' => $count,
            'grossComponentValue' => $gross,
            'balanceDueTotal' => $balance,
            'expectedCommissionTotal' => $expectedCommission,
        ]);
        $this->entityManager->saveEntity($trip);
    }
}
